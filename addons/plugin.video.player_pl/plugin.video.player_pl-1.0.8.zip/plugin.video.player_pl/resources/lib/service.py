# -*- coding: utf-8 -*-

from xbmc import Monitor, Player, getInfoLabel
import xbmc
import time, datetime
import random
import json
import xbmcaddon
import requests
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from .base import b

base=b()

addon = base.addon
baseurl=base.baseurl
platform=base.platform
apiURL=base.apiURL

class BackgroundService(Monitor):
    """ Background service code """

    def __init__(self):
        Monitor.__init__(self)
        self._player = PlayerMonitor()

    def run(self):
        """ Background loop for maintenance tasks """
               
        while not self.abortRequested():

            # Stop when abort requested
            if self.waitForAbort(10):
                break
        
class PlayerMonitor(Player):
    """ A custom Player object to check subtitles """
    
    def __init__(self):
        """ Initialises a custom Player object """
        self.__listen = False

        self.__path = None
        self.__timeplay =0
        self.__totalTime=0
        Player.__init__(self)
        
    def markWatchStatus():
        pass
        
    def onPlayBackStarted(self):  
        """ Will be called when Kodi player starts """
        self.__path = getInfoLabel('Player.FilenameAndPath')
        
        if not self.__path.startswith('plugin://plugin.video.player_pl/?mode=playVid'):
            self.__listen = False
            return
        xbmc.log('start odtwarzania', level=xbmc.LOGINFO)    
        self.__listen = True
                
        while self.__listen and self.isPlaying():
            if self.isPlaying():
                self.__timeplay=self.getTime()
                self.__totalTime=self.getTotalTime()
            time.sleep(2)
        
    def onPlayBackEnded(self):  
        """ Will be called when [Kodi] stops playing a file """
        if not self.__listen:
            return
        xbmc.log('koniec odtwarzaniax', level=xbmc.LOGINFO)
        #xbmc.log(self.__path, level=xbmc.LOGINFO)
        if addon.getSetting('logged')=='true' and addon.getSetting('synchrWithApp')=='true':
            eid=dict(parse_qsl(self.__path.split('?')[-1]))['eid']
            timePlay=int(self.__timeplay)
            
            #przesłanie danych na serwer
            u=apiURL+'subscriber/bookmark'#+'&hash='+addon.getSetting('profile_uid')
            params_url=base.paramsURL()
            params_url.update({
                'type':'WATCHED',
                'itemId[]':[eid]
            })
            data={
                "itemId": int(eid),
                "playTime": timePlay,
                'watchedMinimumPercent':90
            }
            resp=requests.post(u,headers=base.heaGen(),cookies=base.cookiesGen(),json=data,params=params_url)
            if base.authCheck(resp)==False:
                resp=requests.post(u,headers=base.heaGen(),cookies=base.cookiesGen(),json=data,params=params_url)
            if resp.status_code==204:
                xbmc.log('@@@Przesłano playTime na serwer', level=xbmc.LOGINFO)
                        
            #status
            if 'playVid' in self.__path and 'player_pl' in self.__path :
                pathFile='plugin://plugin.video.player_pl/?mode=playVid&eid='+eid+'&profile='+addon.getSetting('profile_uid')
                totalTime=int(self.__totalTime)
                now=int(time.time())
                lastplayed=datetime.datetime.fromtimestamp(now).strftime('%Y-%m-%d %H:%M:%S')
                request={
                        "jsonrpc": "2.0", 
                        "method": "Files.SetFileDetails", 
                        "params": {
                            "file": pathFile, 
                            "media": "video", 
                            "playcount": 1,
                            "lastplayed":lastplayed,
                            "resume": {
                                "position":0, 
                                "total": 0
                            }
                        },
                        "id":"1"
                }
                results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                #print(results)
                
                xbmc.executebuiltin('Container.Refresh()')
                
            req={"jsonrpc": "2.0", "params": {"media": "video","file": pathFile, "properties": ["resume","playcount"]}, "method": "Files.GetFileDetails", "id": "1"}
            results = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
            #print(results)
            
              
            
    def onPlayBackStopped(self):  
        """ Will be called when [user] stops Kodi playing a file """
        if not self.__listen:
            return
        #xbmc.log('@@@Odtwarzanie przerwane - STOP', level=xbmc.LOGINFO)
        #xbmc.log(self.__path, level=xbmc.LOGINFO)
        #xbmc.log(str(self.__timeplay), level=xbmc.LOGINFO)
        #xbmc.log(str(self.__totalTime), level=xbmc.LOGINFO)
        if addon.getSetting('logged')=='true' and addon.getSetting('synchrWithApp')=='true':
            eid=dict(parse_qsl(self.__path.split('?')[-1]))['eid']
            timePlay=int(self.__timeplay)
            totalTime=int(self.__totalTime)
            
            #przesłanie danych na serwer
            u=apiURL+'subscriber/bookmark'#+'&hash='+addon.getSetting('profile_uid')
            params_url=base.paramsURL()
            params_url.update({
                'type':'WATCHED'
            })
            data={
                "itemId": int(eid),
                "playTime": timePlay
            }
            resp=requests.post(u,headers=base.heaGen(),cookies=base.cookiesGen(),json=data,params=params_url)
            if base.authCheck(resp)==False:
                resp=requests.post(u,headers=base.heaGen(),cookies=base.cookiesGen(),json=data,params=params_url)
            if resp.status_code==204:
                xbmc.log('@@@Przesłano playTime na serwer', level=xbmc.LOGINFO)
            
            #status
            pathFile='plugin://plugin.video.player_pl/?mode=playVid&eid='+eid+'&profile='+addon.getSetting('profile_uid')
            if totalTime>0 and 'playVid' in self.__path and 'player_pl' in self.__path:
                request={
                    "jsonrpc": "2.0", 
                    "method": "Files.SetFileDetails", 
                    "params": {
                        "file": pathFile, 
                        "media": "video", 
                        "resume": {
                            "position":timePlay, 
                            "total": totalTime
                        }
                    },
                    "id":"1"
                }
                results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                
                xbmc.executebuiltin('Container.Refresh()') 
            
            req={"jsonrpc": "2.0", "params": {"media": "video","file": pathFile, "properties": ["resume","playcount"]}, "method": "Files.GetFileDetails", "id": "1"}
            results = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
            #print(results)
                
def run():
    """ Run the BackgroundService """
    BackgroundService().run()
