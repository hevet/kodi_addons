# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
import datetime,time
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from html import unescape

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.wp')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

baseurl='https://wp.pl/'
baseurl_money='https://money.pl/'
baseurl_podcast='https://open.fm/'
apiURL_podcasts='https://open.fm/api/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)
    
def ISAplayer(PROTOCOL,url_stream,ref):
    import inputstreamhelper
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=url_stream)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+ref)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+ref) #K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(url_stream,ref):
    url_stream+='|User-Agent='+UA+'&Referer='+ref
    play_item = xbmcgui.ListItem(path=url_stream)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def main_menu():    
    sources=[       
        ['Materiały wideo wp.pl','menu_wideo','','DefaultAddonVideo.png'],
        ['Podcasty','podcasts','','DefaultMusicSongs.png'],
        ['OPEN.FM','open_fm','','DefaultMusicSongs.png'],
        ['ULUBIONE','favList','','DefaultMusicRecentlyAdded.png']
    ]
    for s in sources:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': s[3], 'fanart':fanart}
        url = build_url({'mode':s[1],'type':s[2],'page':'1'})
        addItemList(url, s[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def menu_wideo():
    items=[
        ['Wiadomosci','wideo','news'],
        ['Sport','sport',''],
        ['Biznes (money.pl)','wideo','money'],
        ['Styl życia','wideo','kobieta'],
        ['Show-biznes','wideo','sb'],
    ]
    for s in items:
        img='DefaultGenre.png'
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
        url = build_url({'mode':s[1],'type':s[2],'page':'1'})
        addItemList(url, s[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)


def playVid(mid,ref=baseurl):
    url='https://wideo.wp.pl/api/v2/embed/'+mid+'/secured'
    hea.update({'Referer':baseurl})
    resp=requests.get(url,headers=hea).json()
    url_stream=''
    for r in resp['clip']['url']:
        if 'hls' in r['type']:
            url_stream=r['url']
    if url_stream !='':
        proxyport = addon.getSetting('proxyport') #proxy
        url_stream='http://127.0.0.1:%s/MANIFEST='%(str(proxyport))+url_stream #proxy
        ISAplayer('hls',url_stream,ref)
        
    else:
        xbmcgui.Dialog().notification('WP', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    
def playLive(l,ts,te):
    url_stream=''
    now=time.time()*1000
    if now>int(ts):# and now<int(te):
        ID=l.split('-')[-1].replace('l','')
        url='https://live.wpcdn.pl/api/v1/lives/'+ID
        hea.update({'Referer':baseurl})
        resp=requests.get(url,headers=hea).json()
        if now>int(te):#archiwalne
            if 'url' in resp:
                for r in resp['url']:
                    if 'hls' in r['type']:
                        url_stream=r['url'][0]
        else: #live
            channel=resp['channel']
            url1='https://pilot.wp.pl/api/v1/live/channel/'+str(channel)
            resp1=requests.get(url1,headers=hea).json()
            streams=resp1['data']['stream_channel']['streams']
            for s in streams:
                if 'hls' in s['type']:
                    url_stream=s['url'][0]
        if url_stream !='':
            ISAplayer('hls',url_stream,baseurl)
            
        else:
            xbmcgui.Dialog().notification('WP', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
    else:
        xbmcgui.Dialog().notification('WP', 'Transmisja nie jest jeszcze prowadzona', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

#WIDEO
def wideoList(t,p):
    categs={
        'news':'https://wiadomosci.wp.pl/',
        'money':'https://www.money.pl/',
        'kobieta':'https://kobieta.wp.pl/',
        'sb':'https://pudelek.pl/'
    }
    
    
    hea.update({'Referer':categs[t]})
    url=categs[t]+'wideo' if t not in ['sb'] else categs[t]+'video'
    p='1' if p==None else p
    if p!='1':
        if t in ['money','kobieta','sb']:
            url+='/?strona='+p
        elif t=='news':
            url+='/'+p
    resp=requests.get(url,headers=hea).text
    #print(resp)

    resp1=resp.split('listing-wrapper')[1].split('<ul')[0].split('<a')
    for i in resp1:
        if 'data-title' in i and 'href=' in i:
            title=cleanTxt(re.compile(r'data-title=\"true\">([^<]+?)<').findall(i)[0])
            img=re.compile(r'src=\"([^\"]+?)\"').findall(i)[0]
            URL=re.compile(r'href=\"([^\"]+?)\"').findall(i)[0]
            plot=''
            try:
                plot+='[B]Data: [/B]'+cleanTxt(re.compile(r'>([^<]+?)</time').findall(i)[0])
            except:
                pass
            
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
            url = build_url({'mode':'playWideo','link':URL})
            addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    if 'data-pagination=\"next\"' in resp:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'wideo','type':t,'page':str(int(p)+1)})
        addItemList(url, '[COLOR=yellow]>>> Następna strona[/COLOR]', setArt)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    

def sportList(p):
    base_sport='https://sportowefakty.wp.pl/'
    hea.update({'Referer':base_sport})
    url=base_sport+'wideo'
    p='1' if p==None else p
    if p!='1':
            url+='/strona/'+p
    resp=requests.get(url,headers=hea).text
    #print(resp)

    resp1=resp.split('\"layout-grid\"')[1].split('\"box\"')[0].split('\"layout-box\"')
    for i in resp1:
        if 'teaser' in i and 'href=' in i:
            title=cleanTxt(re.compile(r'alt=\"([^\"]+?)\"').findall(i)[0])
            img=re.compile(r'src=\"([^\"]+?)\"').findall(i)[0]
            URL=re.compile(r'href=\"([^\"]+?)\"').findall(i)[-1]
            URL=base_sport[:-1]+URL
            plot=''
            try:
                plot+='[B]Data: [/B]'+cleanTxt(re.compile(r'<span data-v-276e38fa>([^<]+)</span>').findall(i)[0])
            except:
                pass
            
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
            url = build_url({'mode':'playWideo','link':URL})
            addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    #next
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
    url = build_url({'mode':'sport','page':str(int(p)+1)})
    addItemList(url, '[COLOR=yellow]>>> Następna strona[/COLOR]', setArt)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    

def playWideo(l):
    #hea.update({'Referer':baseurl_money})
    resp=requests.get(l,headers=hea).text
    try:
        dataPlayer=re.compile(r'data-player-wptv=\"([^\"]+?)\"').findall(resp)[0]
        mid=dataPlayer.split('-')[-1]
        playVid(mid,baseurl_money)
    except:
        stream_url=''
        resp=resp.replace('\'','\"')
        vid=re.compile(r'get.wp.tv/\?mid=([^\"]+?)\"').findall(resp)
        #print(vid)
        if len(vid)>0:
            vid=vid[0]
            url='https://wideo.wp.pl/api/v2/embed/'+vid+'/secured'
            resp=requests.get(url,headers=hea).json()
            if 'clip' in resp:
                if resp['clip']!=None:
                    streams=[r['url'] for r in resp['clip']['url'] if 'hls' in r['type']]
                    if len(streams)>0:
                        stream_url=streams[0]
                        
                        proxyport = addon.getSetting('proxyport') #proxy
                        stream_url='http://127.0.0.1:%s/MANIFEST='%(str(proxyport))+stream_url
                        
                        ISAplayer('hls',stream_url,baseurl_money)
            
        if stream_url=='':
            xbmcgui.Dialog().notification('WP', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

#PODCASTY    
def podcasts():
    hea.update({'Referer':baseurl_podcast})
    url=apiURL_podcasts+'podcasts/categories'
    resp=requests.get(url,headers=hea).json()
    for r in resp:
        name=r['name']
        pid=r['slug']
        
        setArt={'icon':'DefaultGenre.png','fanart':fanart}
        url = build_url({'mode':'podcList','pid':str(pid)})
        addItemList(url, name, setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def getBuildId():#
    url=baseurl_podcast+'podcasty'
    hea.update({'Referer':baseurl_podcast})
    resp=requests.get(url,headers=hea).text
    bid=re.compile(r'\"buildId\":\"([^\"]+?)\"').findall(resp)[0]
    return bid

def podcList(pid):
    url=apiURL_podcasts+'podcasts/category/'+pid
    hea.update({'Referer':baseurl_podcast})
    resp=requests.get(url,headers=hea).json()
    for r in resp['podcasts']['content']:
        if r['premium']==False:
            title=r['title']
            pid=r['id']
            slug=r['slug']
            img=r['imageUrl']
            
            iL={}
            setArt={'icon':img,'fanart':fanart}
            url = build_url({'mode':'podcEpList','pid':str(pid),'page':'1'})
            cmItems=[
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wp?mode=podcDet&slug='+slug+')'),
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.wp?mode=favAdd&url='+quote(url)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+')')
            ]
            addItemList(url, title, setArt, contMenu=True, cmItems=cmItems)
    
    xbmcplugin.endOfDirectory(addon_handle)

def podcDet(s):
    url='https://open.fm/_next/data/%s/podcasty/%s.json?params=%s'%(getBuildId(),s,s)
    hea.update({'Referer':baseurl_podcast})
    resp=requests.get(url,headers=hea).json()
    try:
        plot=cleanTxt2(resp['pageProps']['podcast']['description'])
    except:
        plot=''
    
    if plot=='':
        plot='Brak opisu'
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)

def podcEpList(pid,page):
    url=apiURL_podcasts+'podcast/'+pid+'/episodes?page='+page+'&size=:size'
    hea.update({'Referer':baseurl_podcast})
    resp=requests.get(url,headers=hea).json()
    for e in resp['content']:
        title=e['title']
        plot=''
        if 'publishedValue' in e:
            plot+='[B]Data publikacji: [/B]%s\n'%(e['publishedValue'])
        if 'durationValue' in e:
            plot+='[B]Czas: [/B]%s\n'%(e['durationValue'])    
        if 'description' in e:
            plot+='[I]%s[/I]'%(cleanTxt2(e['description']))
        img=e['imageUrl']
        file=e['file']
        
        iL={'plot':plot}
        setArt={'thumb':img,'icon':img,'fanart':img}
        url = build_url({'mode':'playPodc','file':file})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    count=resp['pagination']['size']
    total=resp['pagination']['totalElements']
    p=resp['pagination']['page']
    if p*count+len(resp['content'])<total:
        setArt={'icon':img_empty}
        url = build_url({'mode':'podcEpList','pid':pid,'page':str(int(page)+1)})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)  

def getURLwithToken(u): #helper
    url='https://open.fm/api/user/token?fp='+u
    hea.update({'Referer':baseurl_podcast})
    resp=requests.get(url,headers=hea).json()
    return resp['url']

def playPodc(f):
    ft=getURLwithToken(f)
    ft+='|User-Agent='+UA+'&referer='+baseurl_podcast
    play_item = xbmcgui.ListItem(path=ft)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

#OPEN
def stations(): #helper
    url=apiURL_podcasts+'radio/stations'
    hea.update({'Referer':baseurl_podcast})
    resp=requests.get(url,headers=hea).json()
    return resp
    
def open_fm():
    items=[
        ['Stacje radiowe','RADIO'],
        ['Kanały muzyczne','MUSIC']
    ]
    for i in items:
        setArt={'icon':'DefaultMusicSongs.png','fanart':fanart}
        url = build_url({'mode':'stList','categ':i[1]})
        addItemList(url, i[0], setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def stList(c):
    stData=stations()
    #print(stData)
    channels=[stData[s] for s in list(stData) if stData[s]['contentType']==c and not stData[s]['premium']]
    for ch in channels:
        name=ch['name']
        slug=ch['slug']
        img=ch['logoUrl']
        
        iL={}
        setArt={'thumb':img,'poster':img,'icon':img,'fanart':fanart}
        url = build_url({'mode':'playRadio','slug':slug,'categ':c})
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.wp?mode=favAdd&url='+quote(url)+'&title='+quote(name)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+')')
        ]
        addItemList(url, name, setArt, 'video', isF=False, isPla='true', contMenu=True, cmItems=cmItems)
    
    xbmcplugin.endOfDirectory(addon_handle)
   
def playRadio(slug,c):
    buildId=addon.getSetting('buildId')
    categ='radiowe' if c=='RADIO' else 'muzyczne'
    url=baseurl_podcast+'_next/data/%s/stacje-%s/%s.json?params=%s'%(buildId,categ,slug,slug)
    hea.update({'Referer':baseurl_podcast})
    resp=requests.get(url,headers=hea).json()
    try:
        stData=resp['pageProps']['station']
        stream_url=stData['streamUrl']
    except:
        stream_url=None
    print(stream_url)
    if stream_url!=None:
        if 'urlType' in stData:
            if stData['urlType'] in ['mp3','aac']:
                directPlayer(stream_url,baseurl_podcast)
        if 'open.fm' in stream_url:
            playPodc(stream_url)
        
    else:
        xbmcgui.Dialog().notification('WP', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    '''
    stData=stations()
    channels=[stData[s] for s in list(stData) if stData[s]['slug']==slug]
    if len(channels)>0:
        f=channels[0]['streamUrl']
        playPodc(f)
    else:
        xbmcgui.Dialog().notification('WP', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    '''    
def m3u_gen():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('WP', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('WP', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    
    stData=stations()

    for st in list(stData):
        s=stData[st]
        if not s['premium']:
            chName=s['name']
            chImg=s['logoUrl']
            cid=s['slug']
            categ=s['contentType']
            
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="WP" ,%s\nplugin://plugin.video.wp?mode=playRadio&slug=%s&categ=%s\n' %(chName,chImg,chName,cid,categ)
        
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('WP', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)


#        
def cleanTxt(x):
    toDel=['<p>','</p>','<br>','</br>']
    for i in toDel:
        x=x.replace(i,'')
        
    x=unescape(x)
    return x

def cleanTxt2(x):
    return re.sub(re.compile(r'<.*?>'), '', x)
    

def getBuildId(t):
    url='https://open.fm'
    h={'User-Agent':UA}
    resp=requests.get(url,headers=h).text
    bid=re.compile(r'\"buildId\":\"([^"]+?)\"').findall(resp)
    if len(bid)>0:
        addon.setSetting('buildId',bid[0])
        addon.setSetting('bid_tmp',str(t))
        xbmc.log('@@@Zaktualizowano buildId', level=xbmc.LOGINFO)   
    
#FAV
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)

def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        if 'play' in j[0]:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        contMenu=True
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.wp?mode=favDel&url='+quote(j[0])+')'),
        ]
        setArt=eval(j[3])
        iL=eval(j[2])
        addItemList(j[0], j[1], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,iL,art):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,iL,art])
        xbmcgui.Dialog().notification('WP', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('WP', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)




mode = params.get('mode', None)

if not mode:
    bid_tmp=addon.getSetting('bid_tmp')
    bid_tmp=0 if bid_tmp=='' else int(bid_tmp)
    now=int(time.time())
    if now-bid_tmp>=24*60*60:
        getBuildId(now)
    main_menu()
else:
    if mode=='menu_wideo':
        menu_wideo()
    

    if mode=='playVid':
        mid=params.get('mid')
        playVid(mid)
        
    if mode=='playLive':
        link=baseurl[:-1]+params.get('link')
        ts=params.get('tStart')
        te=params.get('tEnd')
        playLive(link,ts,te)

    #WIDEO
    if mode=='wideo':
        t=params.get('type')
        p=params.get('page')
        wideoList(t,p)
    
    if mode=='sport':
        p=params.get('page')
        sportList(p)
    
    if mode=='playWideo':
        link=params.get('link')
        playWideo(link)
        
    #Podcasty    
    if mode=='podcasts':
        podcasts()
        
    if mode=='podcList':
        pid=params.get('pid')
        podcList(pid)
    
    if mode=='podcEpList':
        pid=params.get('pid')
        page=params.get('page')
        podcEpList(pid,page)
    
    if mode=='playPodc':
        f=params.get('file')
        playPodc(f)
        
    if mode=='podcDet':
        s=params.get('slug')
        podcDet(s)
    
    
    #OPEN
    if mode=='open_fm':
        open_fm()
    
    if mode=='stList':
        categ=params.get('categ')
        stList(categ)
    
    if mode=='playRadio':
        slug=params.get('slug')
        categ=params.get('categ')
        playRadio(slug,categ)
    
    if mode=='m3u_gen':
        m3u_gen()
        
    
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        iL=params.get('iL')
        setart=params.get('setart')
        favAdd(u,t,iL,setart)
   